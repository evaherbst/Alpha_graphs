%%script for generating alpha shapes from rotational joint range of motion data 
%%and exporting as obj

%%input should be a .csv file with rotations as columns, with no frame numnbers. If rotation columns are in xyz order, then
%%the alpha shape will be graphed with X rotation in the X axis.
%%for Maya work, with models where Z = FE, we recommend loading the angles in ZYX order
%%this will yield and alpha shape with Z graphed on the X axis. 

%% enter your input and output file names here
input = 'inputFileNameHere.csv';
objName = 'outputNameHere.obj';
figName = 'figNameHere.fig';
angles = csvread(input);
%% optional angle flipping (to convert between X,Y,Z and Z,Y,X)
%angles = angles(:,[3 2 1]);
%% plot all points

figure(1);
X = angles(:,1); %plot Z colum (1st column) in Matlab X axis
Y = angles(:,2);
Z = angles(:,3);
plot3(X,Y,Z,'o','MarkerFaceColor', '#37C897', 'MarkerEdgeColor', '#37C897','MarkerSize', 2)

xlabel('FE') 
ylabel('ABAD') 
zlabel('LAR')




%% create alpha shape (faces are triangular)
hold on
shape= alphaShape(angles,10); %enter radius or use default - here we are using a radius of 10
face_color = [0.941176470588235 0.941176470588235 0.941176470588235]
edge_color = [0.8 0.8 0.8]
plot(shape,'FaceColor',face_color,'EdgeColor',edge_color);
hold off
alpha(.3); %this sets transparency
xlabel('FE') 
ylabel('ABAD') 
zlabel('LAR')


%%get faces from shape
faces = boundaryFacets(shape);
verts = shape.Points;

disp(faces);
disp(verts);

%%print alpha radius
cA = criticalAlpha(shape,'all-points'); %print the default "all-points" alpha radius

%% plotting specific poses (if using, we recommend commenting out the "plot all points" section and starting by plotting alpha shape)


hold on

c = parula(2) %parula(n) creates n different colors from the parula colormap (color-blind friendly). 
%Set n to the number of different poses you want to plot. In this example
%we create 2 distinct colors
pose_1_color = c(1,:)
pose_2_color= c(3,:)


% REPLACE X,X,X with angles of pose 1
plot3(X,X,X,'o', 'MarkerFaceColor', pose_1_color, 'MarkerEdgeColor', pose_1_color,'MarkerSize', 10) 
hold on

% REPLACE X,X,X with angles of pose 2
plot3(X,X,X,'o', 'MarkerFaceColor', pose_2_color, 'MarkerEdgeColor', pose_2_color,'MarkerSize', 10) 
hold on


%%
vertface2obj(verts,faces,objName)
savefig(figName)
